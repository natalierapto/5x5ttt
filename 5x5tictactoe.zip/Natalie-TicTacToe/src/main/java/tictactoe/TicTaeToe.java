/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Natalie Raptoplous
 */
public class TicTaeToe implements ActionListener{

 //Creating Frame
 JFrame f = new JFrame("Natalie's Tic Tac Toe");

 //Creating Label for printing who is the winner.
 Label lbl=new Label("");

 //Creating button for game board
 JButton btn1 = new JButton("");
 JButton btn2 = new JButton("");
 JButton btn3 = new JButton("");
 JButton btn4 = new JButton("");
 JButton btn5 = new JButton("");
 JButton btn6 = new JButton("");
 JButton btn7 = new JButton("");
 JButton btn8 = new JButton("");
 JButton btn9 = new JButton("");
 JButton btn10 = new JButton("");
 JButton btn11 = new JButton("");
 JButton btn12 = new JButton("");
 JButton btn13 = new JButton("");
 JButton btn14 = new JButton("");
 JButton btn15 = new JButton("");
 JButton btn16 = new JButton("");
 JButton btn17 = new JButton("");
 JButton btn18 = new JButton("");
 JButton btn19 = new JButton("");
 JButton btn20 = new JButton("");
 JButton btn21 = new JButton("");
 JButton btn22 = new JButton("");
 JButton btn23 = new JButton("");
 JButton btn24 = new JButton("");
 JButton btn25 = new JButton("");
 JButton btn26 = new JButton("");
 
 //Creating panels
 JPanel board = new JPanel();
 JPanel panel = new JPanel();

 String letter = "";
 int count = 0;
 
 //Creating flag for winner
 boolean win = false;
 
 public TicTaeToe() {
     //Calling initUI() method to initiliaze UI
     initUI();
     addActionEvents();
 }

 
 @Override
 public void actionPerformed(ActionEvent a) {
 count++;
 if(count == 1 || count == 3 || count == 5 || count == 7 || count == 9 || count == 11 || count == 13 || count == 15 || count == 17 || count == 19 || count == 21 || count == 23 || count == 25){
 letter = "X";
 } else if(count == 2 || count == 4 || count == 6 || count == 8 || count == 10 || count == 12 || count == 14 || count == 16 || count == 18 || count == 20 || count == 22 || count == 24){
 letter = "O";
 }

 if(a.getSource() == btn1){
 btn1.setText(letter);
 btn1.setEnabled(false);
 }else if(a.getSource() == btn2){
 btn2.setText(letter);
 btn2.setEnabled(false);
 } else if(a.getSource() == btn3){
 btn3.setText(letter);
 btn3.setEnabled(false);
 } else if(a.getSource() == btn4){
 btn4.setEnabled(false);
 btn4.setText(letter);
 } else if(a.getSource() == btn5){
 btn5.setText(letter);
  btn5.setEnabled(false);
 } else if(a.getSource() == btn6){
 btn6.setText(letter);
  btn6.setEnabled(false);
 } else if(a.getSource() == btn7){
 btn7.setEnabled(false);
 btn7.setText(letter);
 } else if(a.getSource() == btn8){
 btn8.setEnabled(false);
 btn8.setText(letter);
 } else if(a.getSource() == btn9){
 btn9.setText(letter);
 btn9.setEnabled(false);
 } else if(a.getSource() == btn11){
 btn11.setText(letter);
 btn11.setEnabled(false);
 } else if(a.getSource() == btn12){
 btn12.setText(letter);
 btn12.setEnabled(false);
 } else if(a.getSource() == btn13){
 btn13.setText(letter);
 btn13.setEnabled(false);
 } else if(a.getSource() == btn14){
 btn14.setText(letter);
 btn14.setEnabled(false);
 } else if(a.getSource() == btn15){
 btn15.setText(letter);
 btn15.setEnabled(false);
 } else if(a.getSource() == btn16){
 btn16.setText(letter);
 btn16.setEnabled(false);
 } else if(a.getSource() == btn17){
 btn17.setText(letter);
 btn17.setEnabled(false);
 } else if(a.getSource() == btn18){
 btn18.setText(letter);
 btn18.setEnabled(false);
 } else if(a.getSource() == btn19){
 btn19.setText(letter);
 btn19.setEnabled(false);
 } else if(a.getSource() == btn20){
 btn20.setText(letter);
 btn20.setEnabled(false);
 } else if(a.getSource() == btn21){
 btn21.setText(letter);
 btn21.setEnabled(false);
 } else if(a.getSource() == btn22){
 btn22.setText(letter);
 btn22.setEnabled(false);
 } else if(a.getSource() == btn23){
 btn23.setText(letter);
 btn23.setEnabled(false);
 } else if(a.getSource() == btn24){
 btn24.setText(letter);
 btn24.setEnabled(false);
 } else if(a.getSource() == btn25){
 btn25.setText(letter);
 btn25.setEnabled(false);
 } else if(a.getSource() == btn26){
 btn26.setText(letter);
 btn26.setEnabled(false);
 } 
 else if(a.getSource() == btn10){
     
 //btn10 is for reset
 //Re-setting whole game
 
 letter = "";
 count = 0;
        
 btn1.setEnabled(true);
 btn2.setEnabled(true);
 btn3.setEnabled(true);
 btn4.setEnabled(true); 
 btn5.setEnabled(true);
 btn6.setEnabled(true);
 btn7.setEnabled(true);
 btn8.setEnabled(true);
 btn9.setEnabled(true);
 btn11.setEnabled(true);
 btn12.setEnabled(true);
 btn13.setEnabled(true);
 btn14.setEnabled(true); 
 btn15.setEnabled(true);
 btn16.setEnabled(true);
 btn17.setEnabled(true);
 btn18.setEnabled(true);
 btn19.setEnabled(true);
 btn20.setEnabled(true);
 btn21.setEnabled(true);
 btn22.setEnabled(true);
 btn23.setEnabled(true);
 btn24.setEnabled(true); 
 btn25.setEnabled(true);
 btn26.setEnabled(true);
 
 btn1.setText("");
 btn2.setText("");
 btn3.setText("");
 btn4.setText("");
 btn5.setText("");
 btn6.setText("");
 btn7.setText("");
 btn8.setText("");
 btn9.setText("");
 //btn9.setText("");
 btn11.setText("");
 btn12.setText("");
 btn13.setText("");
 btn14.setText("");
 btn15.setText("");
 btn16.setText("");
 btn17.setText("");
 btn18.setText("");
 btn19.setText("");
 btn20.setText("");
 btn21.setText("");
 btn22.setText("");
 btn23.setText("");
 btn24.setText("");
 btn25.setText("");
 btn26.setText("");
 

 lbl.setText("");
 
 win = false;
 
 }

 //Calling checkWinner() method for to check who is the winner
 checkWinner();
 }
 
 
 private void initUI(){
          
 //Setting up panels layout
 //Creating 3*3=9 grid for game
 board.setLayout(new GridLayout(5,5));
 //panel layout for printing winner of game
 panel.setLayout(new FlowLayout());

 //Setting up buttons background color
 btn1.setBackground(new Color(255,255,255));
 btn2.setBackground(new Color(255,255,255));
 btn3.setBackground(new Color(255,255,255));
 btn4.setBackground(new Color(255,255,255));
 btn5.setBackground(new Color(255,255,255));
 btn6.setBackground(new Color(255,255,255));
 btn7.setBackground(new Color(255,255,255));
 btn8.setBackground(new Color(255,255,255));
 btn9.setBackground(new Color(255,255,255));
 btn10.setBackground(new Color(255,255,255));
 btn11.setBackground(new Color(255,255,255));
 btn12.setBackground(new Color(255,255,255));
 btn13.setBackground(new Color(255,255,255));
 btn14.setBackground(new Color(255,255,255));
 btn15.setBackground(new Color(255,255,255));
 btn16.setBackground(new Color(255,255,255));
 btn17.setBackground(new Color(255,255,255));
 btn18.setBackground(new Color(255,255,255));
 btn19.setBackground(new Color(255,255,255));
 btn20.setBackground(new Color(255,255,255));
 btn21.setBackground(new Color(255,255,255));
 btn22.setBackground(new Color(255,255,255));
 btn23.setBackground(new Color(255,255,255));
 btn24.setBackground(new Color(255,255,255));
 btn25.setBackground(new Color(255,255,255));
 btn26.setBackground(new Color(255,255,255));
 
  //Setting up panel background color
 panel.setBackground(new Color(255,255,255));
 
 //Setting up button label text
 btn10.setText("RESET");
 
 //Setting up buttons border
 btn1.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn2.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn3.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn4.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn5.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn6.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn7.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn8.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn9.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn11.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn12.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn13.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn14.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn15.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn16.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn17.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn18.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn19.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn20.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn21.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn22.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn23.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn24.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn25.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));
 btn26.setBorder(BorderFactory.createLineBorder(Color.decode("#2C6791")));

 //Adding all buttons in board layout
 board.add(btn1);
 board.add(btn2);
 board.add(btn3);
 board.add(btn4);
 board.add(btn5);
 board.add(btn6);
 board.add(btn7);
 board.add(btn8);
 board.add(btn9);
 board.add(btn11);
 board.add(btn12);
 board.add(btn13);
 board.add(btn14);
 board.add(btn15);
 board.add(btn16);
 board.add(btn17);
 board.add(btn18);
 board.add(btn19);
 board.add(btn20);
 board.add(btn21);
 board.add(btn22);
 board.add(btn23);
 board.add(btn24);
 board.add(btn25);
 board.add(btn26);
 
 panel.add(btn10);
 panel.add(lbl);
 
 //Frame is parent of all every panel
 //panels are added in frame
 f.add(board,BorderLayout.CENTER);
 f.add(panel,BorderLayout.SOUTH);
 
 //Setting up icon for frame
 
 f.setVisible(true);
 f.setSize(550,550);
 f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      }
 
    public void addActionEvents(){
        //registering action listener to buttons
         //Adding action listener for what will happen when player clicks on buttons
 btn1.addActionListener(this);
 btn2.addActionListener(this);
 btn3.addActionListener(this);
 btn4.addActionListener(this);
 btn5.addActionListener(this);
 btn6.addActionListener(this);
 btn7.addActionListener(this);
 btn8.addActionListener(this);
 btn9.addActionListener(this);
 btn10.addActionListener(this);
 btn11.addActionListener(this);
 btn12.addActionListener(this);
 btn13.addActionListener(this);
 btn14.addActionListener(this);
 btn15.addActionListener(this);
 btn16.addActionListener(this);
 btn17.addActionListener(this);
 btn18.addActionListener(this);
 btn19.addActionListener(this);
 btn20.addActionListener(this);
 btn21.addActionListener(this);
 btn22.addActionListener(this);
 btn23.addActionListener(this);
 btn24.addActionListener(this);
 btn25.addActionListener(this);
 btn26.addActionListener(this);
 
      
    }
    
      
 private void checkWinner()
 {
   //Checking every condition of tic-tac-toe game
     
     //Check Horizontally
   if(btn1.getText() == btn2.getText() && 
    btn2.getText() == btn3.getText() && 
    btn3.getText() == btn4.getText() && 
    btn4.getText() == btn5.getText() && 
    btn1.getText() != "" && 
    btn2.getText() != "" && 
    btn3.getText() != "" && 
    btn4.getText() != "" &&
    btn5.getText() != "" )
 {
        win = true;
 }
 
        //Check Horizontally
  else if(btn6.getText() == btn7.getText() && 
        btn7.getText() == btn8.getText() && 
        btn8.getText() == btn9.getText() && 
        btn9.getText() == btn11.getText() && 
        btn6.getText() != "" && 
        btn7.getText() != "" && 
        btn8.getText() != "" && 
        btn9.getText() != "" &&
        btn11.getText() != "" )
  {
      win = true;
  }
  
       //Check Horizontally
    else if(btn12.getText() == btn13.getText() && 
        btn13.getText() == btn14.getText() && 
        btn14.getText() == btn15.getText() && 
        btn15.getText() == btn16.getText() && 
        btn12.getText() != "" && 
        btn13.getText() != "" && 
        btn14.getText() != "" && 
        btn15.getText() != "" &&
        btn16.getText() != "" )
    {
        win = true;
    }
       //Check Horizontally
    else if(btn17.getText() == btn18.getText() && 
        btn18.getText() == btn19.getText() && 
        btn19.getText() == btn20.getText() && 
        btn20.getText() == btn21.getText() && 
        btn17.getText() != "" && 
        btn18.getText() != "" && 
        btn19.getText() != "" && 
        btn20.getText() != "" &&
        btn21.getText() != "" )
    {
        win = true;
    }
       //Check Horizontally
    else if(btn22.getText() == btn23.getText() && 
        btn23.getText() == btn24.getText() && 
        btn24.getText() == btn25.getText() && 
        btn25.getText() == btn26.getText() && 
        btn22.getText() != "" && 
        btn23.getText() != "" && 
        btn24.getText() != "" && 
        btn25.getText() != "" &&
        btn26.getText() != "" )
    {
        win = true;
    }
    
        //Check Vertically
    else if(btn1.getText() == btn6.getText() && 
        btn6.getText() == btn12.getText() && 
        btn12.getText() == btn17.getText() && 
        btn17.getText() == btn22.getText() && 
        btn1.getText() != "" && 
        btn6.getText() != "" && 
        btn12.getText() != "" && 
        btn17.getText() != "" &&
        btn22.getText() != "" )
    {
        win = true;
    }
    
        //Check Vertically
    else if(btn2.getText() == btn7.getText() && 
        btn7.getText() == btn13.getText() && 
        btn13.getText() == btn18.getText() && 
        btn18.getText() == btn23.getText() && 
        btn2.getText() != "" && 
        btn7.getText() != "" && 
        btn13.getText() != "" && 
        btn18.getText() != "" &&
        btn23.getText() != "" )
    {
        win = true;
    }
    
        //Check Vertically
    else if(btn3.getText() == btn8.getText() && 
        btn8.getText() == btn14.getText() && 
        btn14.getText() == btn19.getText() && 
        btn19.getText() == btn24.getText() && 
        btn3.getText() != "" && 
        btn8.getText() != "" && 
        btn14.getText() != "" && 
        btn19.getText() != "" &&
        btn24.getText() != "" )
    {
        win = true;
    }
    
    //Check Vertically
    else if(btn4.getText() == btn9.getText() && 
        btn9.getText() == btn15.getText() && 
        btn15.getText() == btn20.getText() && 
        btn20.getText() == btn25.getText() && 
        btn4.getText() != "" && 
        btn9.getText() != "" && 
        btn15.getText() != "" && 
        btn20.getText() != "" &&
        btn25.getText() != "" )
    {
        win = true;
    }
    
    //Check Vertically
    else if(btn5.getText() == btn11.getText() && 
        btn11.getText() == btn16.getText() && 
        btn16.getText() == btn21.getText() && 
        btn21.getText() == btn26.getText() && 
        btn5.getText() != "" && 
        btn11.getText() != "" && 
        btn16.getText() != "" && 
        btn21.getText() != "" &&
        btn26.getText() != "" )
    {
        win = true;
    }
    
    //Check Diagonally
    else if(btn1.getText() == btn7.getText() && 
        btn7.getText() == btn14.getText() && 
        btn14.getText() == btn20.getText() && 
        btn20.getText() == btn26.getText() && 
        btn1.getText() != "" && 
        btn7.getText() != "" && 
        btn14.getText() != "" && 
        btn20.getText() != "" &&
        btn26.getText() != "" )
    {
        win = true;
    }
    
    //Check Diagonally
    else if(btn5.getText() == btn9.getText() && 
        btn9.getText() == btn14.getText() && 
        btn14.getText() == btn18.getText() && 
        btn18.getText() == btn22.getText() && 
        btn5.getText() != "" && 
        btn9.getText() != "" && 
        btn14.getText() != "" && 
        btn18.getText() != "" &&
        btn22.getText() != "" )
    {
            win = true;
    }
    
    else {
        win = false;
    }
 
 if (win) {
     lbl.setText("Hurray! Player " + letter + " wins!");
        btn1.setEnabled(false);
        btn2.setEnabled(false);
        btn3.setEnabled(false);
        btn4.setEnabled(false); 
        btn5.setEnabled(false);
        btn6.setEnabled(false);
        btn7.setEnabled(false);
        btn8.setEnabled(false);
        btn9.setEnabled(false);
        btn11.setEnabled(false);
        btn12.setEnabled(false);
        btn13.setEnabled(false);
        btn14.setEnabled(false); 
        btn15.setEnabled(false);
        btn16.setEnabled(false);
        btn17.setEnabled(false);
        btn18.setEnabled(false);
        btn19.setEnabled(false);
        btn20.setEnabled(false);
        btn21.setEnabled(false);
        btn22.setEnabled(false);
        btn23.setEnabled(false);
        btn24.setEnabled(false); 
        btn25.setEnabled(false);
        btn26.setEnabled(false);

 } else if (!win && count == 25) {
        lbl.setText("The game ended in a tie.");
        btn1.setEnabled(false);
        btn2.setEnabled(false);
        btn3.setEnabled(false);
        btn4.setEnabled(false); 
        btn5.setEnabled(false);
        btn6.setEnabled(false);
        btn7.setEnabled(false);
        btn8.setEnabled(false);
        btn9.setEnabled(false);
        btn11.setEnabled(false);
        btn12.setEnabled(false);
        btn13.setEnabled(false);
        btn14.setEnabled(false); 
        btn15.setEnabled(false);
        btn16.setEnabled(false);
        btn17.setEnabled(false);
        btn18.setEnabled(false);
        btn19.setEnabled(false);
        btn20.setEnabled(false);
        btn21.setEnabled(false);
        btn22.setEnabled(false);
        btn23.setEnabled(false);
        btn24.setEnabled(false); 
        btn25.setEnabled(false);
        btn26.setEnabled(false);
 }
 }
 
 public static void main(String[] args) {
 // TODO code application logic here
TicTaeToe ttt=new TicTaeToe();

 }
}